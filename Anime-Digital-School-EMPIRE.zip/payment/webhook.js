import express from "express";
const app = express();
app.use(express.json());
app.post("/webhook",(req,res)=>{
  console.log("Payment received", req.body);
  res.send("OK");
});
app.listen(4000);